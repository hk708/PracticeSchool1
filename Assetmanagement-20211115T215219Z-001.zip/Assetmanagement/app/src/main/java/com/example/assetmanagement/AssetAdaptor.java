package com.example.assetmanagement;

import android.content.Context;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import java.util.ArrayList;

class SingleItem{
    int imageId;
    String RoomNo;
    SingleItem(int imageId,String RoomNo){
        this.imageId=imageId;
        this.RoomNo=RoomNo;
    }
}
public class AssetAdaptor extends BaseAdapter {
    ArrayList<SingleItem> list;
    Context context;
    AssetAdaptor(Context context){
        this.context=context;
        list=new ArrayList<SingleItem>();
        Resources res=context.getResources();
        String[] RoomNumbers=res.getStringArray(R.array.room_number);
        int images= R.drawable.cupcake;
        for(int i=0;i<9;i++){
            SingleItem temp=new SingleItem(images,RoomNumbers[i]);
            list.add(temp);
        }
    }
    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    class Viewholder{
        ImageView Room;
        Viewholder(View v){
            Room=v.findViewById(R.id.imageView);
        }
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row=convertView;
        Viewholder holder=null;
        if(row==null) {
            LayoutInflater inflator = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row= inflator.inflate(R.layout.single_item, (ViewGroup) convertView,false);
            holder=new Viewholder(row);
            row.setTag(holder);
        }
        else
        {    holder= (Viewholder) row.getTag();
        }
        SingleItem temp=list.get(position);
        holder.Room.setImageResource(temp.imageId);





        return row;
    }
}